# Lint as: python3
# Copyright 2020 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or  implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================
"""Read and write."""
import inspect
import os

_ROOT_DIR = os.path.dirname(inspect.getfile(inspect.currentframe()))


def read_proto(filename: str):
  with open(os.path.join(_ROOT_DIR, filename), 'rb') as f:
    return f.read()


def write_proto(filename: str, serialized):
  with open(os.path.join(_ROOT_DIR, filename), 'wb') as f:
    f.write(serialized)
