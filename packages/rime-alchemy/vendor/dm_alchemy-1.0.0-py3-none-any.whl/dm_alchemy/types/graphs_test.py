# Lint as: python3
# Copyright 2020 DeepMind Technologies Limited. All Rights Reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#    http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or  implied.
# See the License for the specific language governing permissions and
# limitations under the License.
# ============================================================================

from absl.testing import absltest
from dm_alchemy.types import graphs


class GraphsTest(absltest.TestCase):

  def test_graph_constraint_conversion(self):
    constraints = graphs.possible_constraints()
    for constraint in constraints:
      graph = graphs.create_graph_from_constraint(constraint)
      new_constraint = graphs.constraint_from_graph(graph)
      self.assertEqual(constraint, new_constraint)


if __name__ == '__main__':
  absltest.main()
